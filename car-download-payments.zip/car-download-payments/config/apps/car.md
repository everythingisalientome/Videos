---
schema_version: 1
id: car
name: CaR
kind: web
launch:
  browser: chrome
  url: REPLACE_WITH_UAT_LAUNCH_ADDRESS
  wait_seconds: 15
  window_title_contains:
    - "Channel Secure Sign On"
    - "Enterprise Collections and Recovery"
allowed_window:
  match: launched_window
  processes: [chrome.exe]
home:
  how: Click the "Account Locator" tab at the top left of the page.
  looks_like: The Account Locator tab with an "CaR ID" field under General and the buttons Search, Search FDR and Clear.
---

# CaR app context

Exceptions and traps only. Every line was seen in screenshots on 2026-11-23 and has not yet been seen in a run.

- The app runs in its own window with no browser tabs. A second window titled "Launching CaR" stays behind it. Ignore that window.
- The X at the top right corner of the window closes the whole app. Never click it.
- Tabs inside the page, such as "Account Locator" and "Account Information", have their own small x at the right end of the tab title.
- While the app is working it shows a spinner and "Request in process. Please wait" at the top left. Wait until both are gone.
- An opened account always lands on its "Action Log" sub-tab.
- The account page is taller than the screen. A row of buttons (Edit, Save, Cancel, Payment Information, Balance Details) is at the very bottom. Scroll with the pointer over the middle of the page.
- "Payment Information" opens a separate smaller window with a red "Close" button.
- A red line saying customer authentication is not complete is expected on the Details sub-tab.
- Edit, Save, Edit Note, Request Acct and Search FDR change data or start other work. This app context never needs them.

## Known interruptions

None observed yet.
