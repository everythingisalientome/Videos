# Session handoff

Last updated: 2026-11-12. Previous sessions were in Claude chat at home; this file carries the state over to Claude Code at work.

## Where we are

On roadmap step 6 (reading a real response and renormalising). The explanation is done and written up in STUDY_NOTES.md section 9. The exercise for it has not been answered yet.

## Understood so far

| Topic | Status | Notes |
|---|---|---|
| What a logit is | Solid | Raw score, only gaps matter |
| Softmax (e^, then divide by total) | Solid | Worked 2, 1, 0 by hand; knows the total is just the sum |
| Logprob as ln of probability | Solid | Can go logprob to probability with e^ |
| Logit vs probability vs logprob | Recently fixed | Mixed up "0.9 is the logit" once; corrected. Worth one quick re-check |
| Temperature as dividing logits by T | Solid | Computed T = 0.5 and T = 1/3 personally |
| Temperature 0 = pick the top logit | Solid | Asked the divide-by-zero question unprompted |
| Deterministic is not correct | Solid | Raised this unprompted |
| temperature vs logprobs are separate API knobs | Recently fixed | First thought T = 0.5 "gives more options"; corrected |
| Reading `top_logprobs` and renormalising | Explained, not yet practised | Exercise below |

## Open exercise (ask for this first)

```python
import numpy as np

top = {"B": -0.357, "A": -1.609, "\n": -2.996, "C": -3.507}
options = ["A", "B", "C"]

# 1. turn each option's logprob into a probability
# 2. add them up
# 3. divide each by that total
```

Asked to guess before running: which option wins, and is its final percentage higher or lower than its step-1 probability?

<details>
<summary>Answer, for the tutor</summary>

Step 1: B = 0.700, A = 0.200, C = 0.030 (the newline is 0.050 and is ignored).
Total = 0.930.
Final: B = 75.3%, A = 21.5%, C = 3.2%.
B wins, and its share goes up (70% to 75.3%) because the probability that was on non-options is handed back to the options.
</details>

## Next after the exercise

Roadmap step 7: token variants. "A" and " A" are different tokens that mean the same thing to us. Show it with the real Gemma tokenizer, then decide how to handle it (add the variants together).

Then step 8: the first real call to vLLM with one prompt, printing the raw top-20 list. That is the first point where real code runs at work, and it is also where the "to verify" items in CLAUDE.md get checked.

## Things parked on purpose

- A full Banking77 evaluation script was written earlier for the home Mac (MLX, direct logits). It was too much too soon and is not part of this handoff. Rebuild the evaluation step by step when the roadmap reaches it.
- Calibration was introduced by name only. The question "a model says 90% and is right 70% of the time; should T be above or below 1?" was asked and never answered. Bring it back at roadmap step 12.

## How to run a session

1. Read this file and ROADMAP.md.
2. Do a one-question warm-up on the last "recently fixed" topic.
3. Teach one step: explanation, worked example, exercise. Wait for the answer.
4. Append the step to STUDY_NOTES.md and update the tables in this file.
