# Decision One: study notes (part 1)

Logits, softmax, logprobs and temperature, using the examples worked through so far.

## 1. The three names

| Name | What it is | Range | Example (token A) |
|---|---|---|---|
| Logit | The model's raw score for a token. Means nothing alone, only relative to other logits. | Any number | 2 |
| Probability | The token's share of the total. | 0 to 1 | 0.665 |
| Logprob | ln of the probability. Same information, different form. | Zero or negative | -0.408 |

Reading logprobs: closer to 0 means more sure. -0.105 is 90%. -2.4 is 9%.

## 2. The sequence

Example: logits A = 2, B = 1, C = 0, with temperature T = 0.5. Values shown are for token A.

| Step | Operation | A's value | What it does and why | Part of softmax? |
|---|---|---|---|---|
| 1. Logit | Model's raw score | 2 | The model's last layer gives one score per token. Only the gaps between scores matter. | No |
| 2. Temperature | Divide by T (0.5) | 4 | Stretches or squeezes the gaps. Changes how sure the model sounds, never the ranking. At T = 1 it does nothing. | No |
| 3. Exponential | e^4 | 54.598 | Makes every score positive and turns gaps into ratios. | Yes |
| 4. Divide by total | 54.598 ÷ 62.987 | 0.867 (probability) | Turns each number into its share of the whole, so everything adds up to 1. | Yes |
| 5. Log | ln(0.867) | -0.143 (logprob) | Rewrites the probability in a form that is easier to store and add. e^ undoes it. | No |

Softmax is steps 3 and 4 together.

### Where the totals come from

The total is just the sum of the step-3 values for every token. It has no meaning of its own; it changes with every set of logits.

**With T = 1** (logits 2, 1, 0):

| Token | Logit | e^logit |
|---|---|---|
| A | 2 | 7.389 |
| B | 1 | 2.718 |
| C | 0 | 1.000 |
| **Total** | | **7.389 + 2.718 + 1.000 = 11.107** |

Shares: A = 7.389 ÷ 11.107 = 0.665, B = 2.718 ÷ 11.107 = 0.245, C = 1.000 ÷ 11.107 = 0.090.

**With T = 0.5** (logits become 4, 2, 0):

| Token | Logit ÷ 0.5 | e^that |
|---|---|---|
| A | 4 | 54.598 |
| B | 2 | 7.389 |
| C | 0 | 1.000 |
| **Total** | | **54.598 + 7.389 + 1.000 = 62.987** |

Shares: A = 0.867, B = 0.117, C = 0.016.

Same idea as votes: three candidates get 7,389, 2,718 and 1,000 votes; divide each by the 11,107 total to get their percentage.

### In code

```python
import numpy as np
logits = np.array([2.0, 1.0, 0.0])
T = 1.0
scaled = logits / T                          # step 2
exps = np.exp(scaled)                        # step 3
probs = exps / exps.sum()                    # step 4 (exps.sum() is the 11.107)
logprobs = np.log(probs)                     # step 5
```

## 3. What happens inside the model server, and what it returns

One request for one output token, in order:

| # | Where | What happens | Example |
|---|---|---|---|
| 1 | Server | Prompt text is split into tokens | "Is this fraud? Answer A or B" |
| 2 | Server | Model reads the tokens and produces one logit for **every** token in its vocabulary (hundreds of thousands) | A: 2, B: 1, C: 0, ... |
| 3 | Server | Divide by temperature | Skipped as a division when T = 0 (see section 5) |
| 4 | Server | Softmax: e^, then divide by total | A: 0.665, B: 0.245, C: 0.090 |
| 5 | Server | **Choose** one token. T = 0: take the top one. T above 0: weighted dice roll. | A |
| 6 | Server | Take ln of the probabilities to get logprobs | A: -0.408, B: -1.408, C: -2.408 |
| 7 | Returned | The chosen token, plus (only if asked) the logprobs of the top N tokens | see below |
| 8 | Our code | e^logprob to get probabilities back | A: 66.5%, B: 24.5%, C: 9.0% |

What comes back, simplified:

```
chosen token:  "A"
top logprobs:  "A": -0.408
               "B": -1.408
               "C": -2.408
```

What the server does **not** return: the raw logits, and the total (the 11.107). Neither is needed, because logprobs carry the same information (section 4).

Two parts worth keeping separate:

- **Scoring** (rows 2 to 4): the same prompt always gives the same scores. Temperature 0 or 1 makes no difference to what the model thinks.
- **Choosing** (row 5): the only place randomness enters.

## 4. Rules learned from the exercises

- **Adding the same number to every logit changes nothing.** Only the differences between logits matter.
- **Multiplying or dividing every logit changes the confidence, never the ranking.**
- **A logprob is the logit minus a constant.** With logits 4, 2, 0 the logprobs were -0.143, -2.143, -4.143: same gaps of 2. The constant is ln(total), here ln(62.987) = 4.143.
- **Probability and logprob convert both ways.** ln one way, e^ back.
- **Logprob to logit is not possible** (the constant is hidden), and it does not matter, because only differences count.

## 5. Temperature

Temperature (T) is the number the logits are divided by before softmax.

| T | Logits after dividing | A | B | C | Effect |
|---|---|---|---|---|---|
| 3 | 0.67, 0.33, 0 | 44.8% | 32.1% | 23.0% | Less sure |
| 1 | 2, 1, 0 | 66.5% | 24.5% | 9.0% | Unchanged |
| 0.5 | 4, 2, 0 | 86.7% | 11.7% | 1.6% | More sure |
| 1/3 | 6, 3, 0 | 95.0% | 4.7% | 0.2% | More sure |
| 0.1 | 20, 10, 0 | 99.995% | tiny | tiny | Almost certain |

- T above 1 squeezes scores together: less sure.
- T below 1 spreads scores apart: more sure.
- Multiplying by 3 is the same as T = 1/3.

### What happens at temperature 0

Dividing by zero is undefined, so the server does not divide. It takes a shortcut:

1. Model produces logits (same as always).
2. Server picks the token with the highest logit. No dice roll.

This matches where the table above is heading: as T shrinks, the top token's share goes to 100%.

## 6. Deterministic is not the same as correct

- Temperature 0 makes output **repeatable**. It does not make it **right**.
- It also **hides how close the race was**. Logits 2.1 and 2.0 give 52.5% vs 47.5%, but at T = 0 the model answers A every time and looks certain.

Two ways to be wrong:

| Kind | Example | How to catch it |
|---|---|---|
| Unsure but forced to pick | 52.5% vs 47.5% | Read the logprobs |
| Sure and wrong | 95% on the wrong answer | Test on labelled data and count (calibration) |

## 7. Two separate API knobs

| Knob | Controls |
|---|---|
| `temperature` | How the one output token is chosen |
| `logprobs` / `top_logprobs` | Whether the server shows the scores, and for how many top tokens |

Temperature does not give more options. The model always scores every token. Asking for logprobs is what makes them visible.

## 8. What this means for Decision One

1. Call the API: temperature 0, one output token, logprobs on.
2. Server does the steps in section 3 and returns the chosen token plus logprobs.
3. Our code goes one step back: e^logprob gives the probability for each option.
4. Later, on our side: apply our own T to make the confidence honest (calibration).

## Still to check on our setup

- Whether the `temperature` sent to the server changes the logprobs it returns. Test with one prompt at two temperatures.

## 9. Reading a real response and renormalising

Prompt: customer message "I see a charge I didn't make." Options A: fraud, B: refund request, C: lost card. Reply with only the letter. (Numbers below are illustrative.)

Shape of an OpenAI-style response (vLLM follows it), trimmed:

```json
"logprobs": {
  "content": [
    {
      "token": "A",
      "logprob": -0.223,
      "top_logprobs": [
        {"token": "A",   "logprob": -0.223},
        {"token": "B",   "logprob": -2.303},
        {"token": "The", "logprob": -3.507},
        {"token": "C",   "logprob": -3.912},
        {"token": " A",  "logprob": -4.605}
      ]
    }
  ]
}
```

- `token` is the one the server chose.
- `top_logprobs` is the table behind the choice: the top N candidates, best first.

**Step 1: e^logprob for each row**

| Token | Logprob | Probability |
|---|---|---|
| A | -0.223 | 80% |
| B | -2.303 | 10% |
| The | -3.507 | 3% |
| C | -3.912 | 2% |
| " A" (with a space) | -4.605 | 1% |

These add up to 96%. The other 4% is spread over the rest of the vocabulary. "The" is noise: the model considered starting a sentence instead of answering with a letter.

**Step 2: keep only our options and re-share (renormalise)**

Total of our options = 0.80 + 0.10 + 0.02 = 0.92.

| Option | Probability | Divide by 0.92 | Final |
|---|---|---|---|
| A (fraud) | 0.80 | 0.80 ÷ 0.92 | 87.0% |
| B (refund request) | 0.10 | 0.10 ÷ 0.92 | 10.9% |
| C (lost card) | 0.02 | 0.02 ÷ 0.92 | 2.2% |

Same divide-by-total move as softmax, done among our options only. This is what Decision One returns.

Set aside for a later step: " A" with a space is a different token from "A".

## Next step

See SESSION.md for the open exercise and ROADMAP.md for what comes after.
