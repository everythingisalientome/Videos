# Decision One

## What this project is

A "decisions API" built on an ordinary generative model: give it a state, a question and a fixed list of options, and get back a probability for each option. No generated text.

How it works: one call to a generation API with temperature 0, one output token, and logprobs turned on. Each option is a short label (A, B, C). We read the logprobs for those labels from the first output token, convert them to probabilities, and re-share them so the options add up to 100%.

Why: it is a baseline to compare against TypeSafe AI's Jev (a "System One" model that returns typed decisions with calibrated probabilities). It also becomes the serving wrapper for a fine-tuned small Gemma later, so a fine-tune is a weight swap and not a new system.

## This is a learning project first

The owner is learning the underlying ML (logits, softmax, logprobs, calibration) as a path towards fine-tuning. Building is secondary to understanding. Follow these rules:

- **One small step at a time.** Do not jump to a full solution. Do not write the whole program up front.
- **Teach with concrete worked examples and real numbers**, not definitions. The owner learns by examples, not memorisation.
- **Assume limited maths and Python.** Explain every operation the first time it appears, including each line of code that is not obvious.
- **End each step with a small exercise or a prediction to make**, then wait for the answer before moving on.
- **When an answer is wrong or mixed up, say exactly which part is right and which is not**, then re-explain with a different example.
- **Reuse the running example** (logits A = 2, B = 1, C = 0) so new ideas connect to old ones.
- **After each completed step, append it to STUDY_NOTES.md and update SESSION.md.**
- Lead with design reasoning before code. Be direct and precise. Critique proposals instead of agreeing by default. Push back on over-engineering. Prefer evidence (run it and look) over assumption.

## Files

| File | Purpose |
|---|---|
| CLAUDE.md | This file: project context and working rules |
| SESSION.md | Where we stopped, the open exercise, what to do next |
| ROADMAP.md | The ordered learning and build steps |
| STUDY_NOTES.md | The owner's running notes, part 1 so far. Append, never rewrite earlier sections without asking |

Start every session by reading SESSION.md and ROADMAP.md.

## Work environment

- Self-hosted only. No managed cloud AI services.
- Gemma 4 31B served on vLLM, on an H100 GPU. A smaller Gemma 4 can be used for speed.
- vLLM exposes an OpenAI-style API. Use the `openai` Python client pointed at the vLLM base URL.
- Do not assume internet access or free package installs. Check what is installed before proposing a dependency, and ask before adding one.
- Public datasets such as Banking77 may not be downloadable here. The intended evaluation data at work is the team's own generic labelled emails. Never paste real customer data into prompts, notes or commits; use made-up examples in docs.

## Design decisions so far

- Labels, not option text: each option maps to a label that is a single token.
- Temperature 0, `max_tokens=1`, `logprobs=True`, `top_logprobs=20`.
- Convert with e^logprob, then renormalise over the option labels only.
- Any temperature adjustment for calibration happens in our code, not as the API setting.
- Keep it to one function, roughly `decide(state, question, options) -> {option: probability}`. No framework.

## Known limits (do not hide these)

- Probabilities from a generative model are not calibrated out of the box. They tend to be overconfident and biased towards certain labels and positions.
- `top_logprobs` is capped at 20 in OpenAI-style APIs, so more than about 20 options needs constrained decoding or a two-stage route.
- No reasoning happens before the answer, so hard decisions will be less accurate than with step-by-step thinking.
- Each field is answered independently; nothing enforces consistency between fields.
- "Cannot hallucinate" only means the output is always a valid option. It can still be the wrong option.

## To verify on this setup (not yet tested)

- Whether the `temperature` sent to vLLM changes the logprobs it returns. Test one prompt at two temperatures.
- The exact vLLM parameter for restricting output to a list of choices. The name has changed between versions; check the installed version's docs.
- That thinking mode is off for Gemma 4 so the first token is the answer.
- That each chosen label is a single token in the Gemma tokenizer, and how "A" versus " A" (with a leading space) shows up.
