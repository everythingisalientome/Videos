# Roadmap

One step per sitting is fine. Each step is: explanation, worked example, small exercise, then notes. Do not start a step until the one before it is understood.

## Part 1: the maths (no model needed)

| # | Step | Status |
|---|---|---|
| 1 | Logits and softmax | Done |
| 2 | Logprobs | Done |
| 3 | Temperature | Done |
| 4 | Temperature 0, and deterministic vs correct | Done |
| 5 | The two API knobs: temperature and logprobs | Done |
| 6 | Reading a `top_logprobs` response and renormalising over our options | Exercise open |

## Part 2: first contact with the real model

| # | Step | What gets learned |
|---|---|---|
| 7 | Token variants | "A" vs " A"; what a tokenizer does; why labels must be single tokens |
| 8 | First real call to vLLM | One prompt, print the raw top-20 list, read it by eye. Also test whether the API temperature changes returned logprobs |
| 9 | Getting the answer into the first token | Prompt wording, thinking mode off, why "The" and newline show up and how to squeeze them out |
| 10 | Write `decide()` | The first real piece of Decision One: about 20 lines, one function |

## Part 3: is it any good?

| # | Step | What gets learned |
|---|---|---|
| 11 | Accuracy on a small labelled set | 20 to 50 examples with known answers; count how many are right |
| 12 | Calibration | Group answers by stated confidence and compare with how often they were right. Revisit: "says 90%, right 70%; T above or below 1?" |
| 13 | Temperature scaling | Find the one T that makes confidence honest, using held-out examples |
| 14 | Label and position bias | Shuffle the option order and watch the answers move |

## Part 4: making it useful

| # | Step | What gets learned |
|---|---|---|
| 15 | More than 20 options | The top-20 cap; restricting output to a list; two-stage routing (coarse, then fine) |
| 16 | Several questions about one state | Same long state, many short questions; why a shared prefix makes this cheap |
| 17 | Compare with Jev | Same data, same metrics (accuracy and calibration), side by side |

## Part 5: bridge to fine-tuning

| # | Step | What gets learned |
|---|---|---|
| 18 | The training loss | Loss is minus the logprob of the correct answer. Everything in part 1 is what training pushes on |
| 19 | Fine-tune a small Gemma on labelled emails | Same `decide()` wrapper, new weights |
| 20 | Before and after | Re-run steps 11 to 13 on the fine-tuned model and compare |

## Guardrails

- No framework. `decide()` stays one function until a real second use case forces otherwise.
- Every claim about quality comes from a run on labelled data, not from a feeling.
- If a step turns out to need two new ideas, split it.
